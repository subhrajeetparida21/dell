Dummy system file: README.txt
